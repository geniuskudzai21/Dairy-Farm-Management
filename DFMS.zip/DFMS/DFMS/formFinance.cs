﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DFMS
{
    public partial class formFinance : Form
    {
        public formFinance()
        {
            InitializeComponent();
        }

        private void expenditureDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void formFinance_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dairymanagementDataSet.MilkSalesTbl' table. You can move, or remove it, as needed.
            this.milkSalesTblTableAdapter.Fill(this.dairymanagementDataSet.MilkSalesTbl);
            // TODO: This line of code loads data into the 'dairymanagementDataSet.MilkSalesTbl' table. You can move, or remove it, as needed.
            this.milkSalesTblTableAdapter.Fill(this.dairymanagementDataSet.MilkSalesTbl);
            // TODO: This line of code loads data into the 'dairymanagementDataSet.IncomeTbl' table. You can move, or remove it, as needed.
            this.incomeTblTableAdapter.Fill(this.dairymanagementDataSet.IncomeTbl);
            // TODO: This line of code loads data into the 'dairymanagementDataSet.Expenditure' table. You can move, or remove it, as needed.
            this.expenditureTableAdapter.Fill(this.dairymanagementDataSet.Expenditure);
            // TODO: This line of code loads data into the 'dairymanagementDataSet.EmployeeTbl' table. You can move, or remove it, as needed.
            this.employeeTblTableAdapter.Fill(this.dairymanagementDataSet.EmployeeTbl);

        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            this.expenditureBindingSource.AddNew();
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            System.Media.SystemSounds.Beep.Play();
            this.expenditureBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dairymanagementDataSet);
            MessageBox.Show("Record Saved successfuly!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            System.Media.SystemSounds.Beep.Play();
            if (MessageBox.Show("Are you sure you want to go back?", "Confirm Back", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Form1 menuForm = new Form1();
                menuForm.Show();
                this.Close();
            }
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            System.Media.SystemSounds.Beep.Play();
            if (MessageBox.Show("Are you sure you want to exit?", "Confirm exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void purposeToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.expenditureTableAdapter.Purpose(this.dairymanagementDataSet.Expenditure, expPurposeToolStripTextBox.Text);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void employIDToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.expenditureTableAdapter.EmployID(this.dairymanagementDataSet.Expenditure, new System.Nullable<int>(((int)(System.Convert.ChangeType(empidToolStripTextBox.Text, typeof(int))))));
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}

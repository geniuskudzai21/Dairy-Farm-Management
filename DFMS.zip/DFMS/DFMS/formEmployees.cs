﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DFMS
{
    public partial class formEmployees : Form
    {
        public formEmployees()
        {
            InitializeComponent();
        }

        private void employeeTblBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.employeeTblBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dairymanagementDataSet);

        }

        private void formEmployees_Load(object sender, EventArgs e)
        {
           
            this.employeeTblTableAdapter.Fill(this.dairymanagementDataSet.EmployeeTbl);

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            System.Media.SystemSounds.Beep.Play();
            this.employeeTblBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dairymanagementDataSet);
            MessageBox.Show("Record Saved successfuly!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            this.employeeTblBindingSource.AddNew();
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            System.Media.SystemSounds.Beep.Play();
            if (MessageBox.Show("Are you sure you want to delete the record?", "Confirm deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.employeeTblBindingSource.RemoveCurrent();
                this.tableAdapterManager.UpdateAll(this.dairymanagementDataSet);
                MessageBox.Show("Record Deleted successfuly!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void Btnback_Click(object sender, EventArgs e)
        {
            System.Media.SystemSounds.Beep.Play();
            if (MessageBox.Show("Are you sure you want to log off?", "Confirm Back", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                formLogin login = new formLogin();
                login.Show();
                this.Close();
            }
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            System.Media.SystemSounds.Beep.Play();
            if (MessageBox.Show("Are you sure you want to exit?", "Confirm exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void genderComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }
    }
}

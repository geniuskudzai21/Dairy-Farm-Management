﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DFMS
{
    public partial class Form1 : Form
    {
   

        public Form1()
        {
            InitializeComponent();
        }

        private void BtnCattle_Click(object sender, EventArgs e)
        {
            Form cattle = new formCattle();
            cattle.Show();
            this.Hide();
        }

        private void BtnBreeding_Click(object sender, EventArgs e)
        {
            Form breeding = new formBreeding();
            breeding.Show();
            this.Hide();
        }

        private void BtnHealth_Click(object sender, EventArgs e)
        {
            Form health = new formHealth();
            health.Show();
            this.Hide();
        }

        private void BtnDashboard_Click(object sender, EventArgs e)
        {
            Form dashboard = new formDashboad();
            dashboard.Show();
            this.Hide();
        }

        private void BtnMilkproduction_Click(object sender, EventArgs e)
        {
            Form milkproduction = new formMilkproduction();
            milkproduction.Show();
            this.Hide();
        }

        private void Btnmilksales_Click(object sender, EventArgs e)
        {
            Form milksales = new formMilksales();
            milksales.Show();
            this.Hide();
        }

        private void BtnFinance_Click(object sender, EventArgs e)
        {
            Form finance = new formFinance();
            finance.Show();
            this.Hide();
        }

       

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            System.Media.SystemSounds.Beep.Play();
            if (MessageBox.Show("Are you sure you want to exit the system?", "Confirm exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            System.Media.SystemSounds.Beep.Play();
            if (MessageBox.Show("Are you sure you want to logoff?", "Confirm Back", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                formLogin login = new formLogin();
               login.Show();
                this.Close();
            }
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}

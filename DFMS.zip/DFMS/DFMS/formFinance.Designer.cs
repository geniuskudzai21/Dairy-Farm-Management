﻿namespace DFMS
{
    partial class formFinance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label empIDLabel;
            System.Windows.Forms.Label expPurposeLabel;
            System.Windows.Forms.Label expAmountLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formFinance));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.expenditureDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.expenditureBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dairymanagementDataSet = new DFMS.dairymanagementDataSet();
            this.milkSalesTblDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.milkSalesTblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.employIDToolStrip = new System.Windows.Forms.ToolStrip();
            this.empidToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.empidToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.employIDToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.purposeToolStrip = new System.Windows.Forms.ToolStrip();
            this.expPurposeToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.expPurposeToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.purposeToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.BtnSave = new Guna.UI2.WinForms.Guna2Button();
            this.empidComboBox = new System.Windows.Forms.ComboBox();
            this.employeeTblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.expDateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.BtnAdd = new Guna.UI2.WinForms.Guna2Button();
            this.expPurposeComboBox = new System.Windows.Forms.ComboBox();
            this.expAmountTextBox = new System.Windows.Forms.TextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.employeeTblTableAdapter = new DFMS.dairymanagementDataSetTableAdapters.EmployeeTblTableAdapter();
            this.expenditureTableAdapter = new DFMS.dairymanagementDataSetTableAdapters.ExpenditureTableAdapter();
            this.tableAdapterManager = new DFMS.dairymanagementDataSetTableAdapters.TableAdapterManager();
            this.incomeTblTableAdapter = new DFMS.dairymanagementDataSetTableAdapters.IncomeTblTableAdapter();
            this.milkSalesTblTableAdapter = new DFMS.dairymanagementDataSetTableAdapters.MilkSalesTblTableAdapter();
            this.incomeTblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            empIDLabel = new System.Windows.Forms.Label();
            expPurposeLabel = new System.Windows.Forms.Label();
            expAmountLabel = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.expenditureDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.expenditureBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dairymanagementDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.milkSalesTblDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.milkSalesTblBindingSource)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.employIDToolStrip.SuspendLayout();
            this.purposeToolStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.employeeTblBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.incomeTblBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // empIDLabel
            // 
            empIDLabel.AutoSize = true;
            empIDLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            empIDLabel.Location = new System.Drawing.Point(38, 82);
            empIDLabel.Name = "empIDLabel";
            empIDLabel.Size = new System.Drawing.Size(68, 18);
            empIDLabel.TabIndex = 24;
            empIDLabel.Text = "Emp ID:";
            // 
            // expPurposeLabel
            // 
            expPurposeLabel.AutoSize = true;
            expPurposeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            expPurposeLabel.Location = new System.Drawing.Point(163, 82);
            expPurposeLabel.Name = "expPurposeLabel";
            expPurposeLabel.Size = new System.Drawing.Size(66, 16);
            expPurposeLabel.TabIndex = 38;
            expPurposeLabel.Text = "Purpose";
            // 
            // expAmountLabel
            // 
            expAmountLabel.AutoSize = true;
            expAmountLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            expAmountLabel.Location = new System.Drawing.Point(162, 137);
            expAmountLabel.Name = "expAmountLabel";
            expAmountLabel.Size = new System.Drawing.Size(59, 16);
            expAmountLabel.TabIndex = 39;
            expAmountLabel.Text = "Amount";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Controls.Add(this.pictureBox3);
            this.groupBox1.Controls.Add(this.groupBox4);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.pictureBox2);
            this.groupBox1.Controls.Add(this.groupBox5);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(3, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(980, 645);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(861, 6);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.pictureBox3.Size = new System.Drawing.Size(111, 76);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 35;
            this.pictureBox3.TabStop = false;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.expenditureDataGridView);
            this.groupBox4.Controls.Add(this.milkSalesTblDataGridView);
            this.groupBox4.Location = new System.Drawing.Point(310, 104);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(661, 553);
            this.groupBox4.TabIndex = 33;
            this.groupBox4.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(243, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(165, 24);
            this.label4.TabIndex = 31;
            this.label4.Text = "Expenditures list";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(270, 275);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(110, 24);
            this.label5.TabIndex = 33;
            this.label5.Text = "Income list";
            // 
            // expenditureDataGridView
            // 
            this.expenditureDataGridView.AutoGenerateColumns = false;
            this.expenditureDataGridView.BackgroundColor = System.Drawing.Color.White;
            this.expenditureDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.expenditureDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.expenditureDataGridView.DataSource = this.expenditureBindingSource;
            this.expenditureDataGridView.Location = new System.Drawing.Point(6, 36);
            this.expenditureDataGridView.Name = "expenditureDataGridView";
            this.expenditureDataGridView.Size = new System.Drawing.Size(647, 220);
            this.expenditureDataGridView.TabIndex = 30;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "ExpID";
            this.dataGridViewTextBoxColumn1.HeaderText = "ExpID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn2.DataPropertyName = "ExpDate";
            this.dataGridViewTextBoxColumn2.HeaderText = "ExpDate";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "ExpPurpose";
            this.dataGridViewTextBoxColumn3.HeaderText = "ExpPurpose";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "ExpAmount";
            this.dataGridViewTextBoxColumn4.HeaderText = "ExpAmount";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Empid";
            this.dataGridViewTextBoxColumn5.HeaderText = "Empid";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // expenditureBindingSource
            // 
            this.expenditureBindingSource.DataMember = "Expenditure";
            this.expenditureBindingSource.DataSource = this.dairymanagementDataSet;
            // 
            // dairymanagementDataSet
            // 
            this.dairymanagementDataSet.DataSetName = "dairymanagementDataSet";
            this.dairymanagementDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // milkSalesTblDataGridView
            // 
            this.milkSalesTblDataGridView.AutoGenerateColumns = false;
            this.milkSalesTblDataGridView.BackgroundColor = System.Drawing.Color.White;
            this.milkSalesTblDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.milkSalesTblDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn13});
            this.milkSalesTblDataGridView.DataSource = this.milkSalesTblBindingSource;
            this.milkSalesTblDataGridView.Location = new System.Drawing.Point(6, 302);
            this.milkSalesTblDataGridView.Name = "milkSalesTblDataGridView";
            this.milkSalesTblDataGridView.Size = new System.Drawing.Size(647, 231);
            this.milkSalesTblDataGridView.TabIndex = 36;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Date";
            this.dataGridViewTextBoxColumn6.HeaderText = "Date";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn11.DataPropertyName = "Empid";
            this.dataGridViewTextBoxColumn11.HeaderText = "Empid";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn13.DataPropertyName = "Total";
            this.dataGridViewTextBoxColumn13.HeaderText = "Total";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            // 
            // milkSalesTblBindingSource
            // 
            this.milkSalesTblBindingSource.DataMember = "MilkSalesTbl";
            this.milkSalesTblBindingSource.DataSource = this.dairymanagementDataSet;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.employIDToolStrip);
            this.groupBox3.Controls.Add(this.purposeToolStrip);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(expAmountLabel);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.BtnSave);
            this.groupBox3.Controls.Add(this.empidComboBox);
            this.groupBox3.Controls.Add(this.expDateDateTimePicker);
            this.groupBox3.Controls.Add(empIDLabel);
            this.groupBox3.Controls.Add(this.BtnAdd);
            this.groupBox3.Controls.Add(this.expPurposeComboBox);
            this.groupBox3.Controls.Add(expPurposeLabel);
            this.groupBox3.Controls.Add(this.expAmountTextBox);
            this.groupBox3.Location = new System.Drawing.Point(12, 104);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(283, 462);
            this.groupBox3.TabIndex = 31;
            this.groupBox3.TabStop = false;
            // 
            // employIDToolStrip
            // 
            this.employIDToolStrip.BackColor = System.Drawing.Color.Black;
            this.employIDToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.employIDToolStrip.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employIDToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.empidToolStripLabel,
            this.empidToolStripTextBox,
            this.employIDToolStripButton});
            this.employIDToolStrip.Location = new System.Drawing.Point(3, 371);
            this.employIDToolStrip.Name = "employIDToolStrip";
            this.employIDToolStrip.Size = new System.Drawing.Size(275, 28);
            this.employIDToolStrip.TabIndex = 1;
            this.employIDToolStrip.Text = "employIDToolStrip";
            // 
            // empidToolStripLabel
            // 
            this.empidToolStripLabel.ForeColor = System.Drawing.Color.White;
            this.empidToolStripLabel.Name = "empidToolStripLabel";
            this.empidToolStripLabel.Size = new System.Drawing.Size(98, 25);
            this.empidToolStripLabel.Text = "EmployeeID";
            // 
            // empidToolStripTextBox
            // 
            this.empidToolStripTextBox.Name = "empidToolStripTextBox";
            this.empidToolStripTextBox.Size = new System.Drawing.Size(100, 28);
            // 
            // employIDToolStripButton
            // 
            this.employIDToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.employIDToolStripButton.ForeColor = System.Drawing.Color.White;
            this.employIDToolStripButton.Name = "employIDToolStripButton";
            this.employIDToolStripButton.Size = new System.Drawing.Size(63, 25);
            this.employIDToolStripButton.Text = "Search";
            this.employIDToolStripButton.Click += new System.EventHandler(this.employIDToolStripButton_Click);
            // 
            // purposeToolStrip
            // 
            this.purposeToolStrip.BackColor = System.Drawing.Color.Black;
            this.purposeToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.purposeToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.expPurposeToolStripLabel,
            this.expPurposeToolStripTextBox,
            this.purposeToolStripButton});
            this.purposeToolStrip.Location = new System.Drawing.Point(3, 319);
            this.purposeToolStrip.Name = "purposeToolStrip";
            this.purposeToolStrip.Size = new System.Drawing.Size(277, 28);
            this.purposeToolStrip.TabIndex = 1;
            this.purposeToolStrip.Text = "purposeToolStrip";
            // 
            // expPurposeToolStripLabel
            // 
            this.expPurposeToolStripLabel.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.expPurposeToolStripLabel.ForeColor = System.Drawing.Color.White;
            this.expPurposeToolStripLabel.Name = "expPurposeToolStripLabel";
            this.expPurposeToolStripLabel.Size = new System.Drawing.Size(100, 25);
            this.expPurposeToolStripLabel.Text = "ExpPurpose:";
            // 
            // expPurposeToolStripTextBox
            // 
            this.expPurposeToolStripTextBox.Name = "expPurposeToolStripTextBox";
            this.expPurposeToolStripTextBox.Size = new System.Drawing.Size(100, 28);
            // 
            // purposeToolStripButton
            // 
            this.purposeToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.purposeToolStripButton.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.purposeToolStripButton.ForeColor = System.Drawing.Color.White;
            this.purposeToolStripButton.Name = "purposeToolStripButton";
            this.purposeToolStripButton.Size = new System.Drawing.Size(63, 25);
            this.purposeToolStripButton.Text = "Search";
            this.purposeToolStripButton.Click += new System.EventHandler(this.purposeToolStripButton_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(92, 275);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 24);
            this.label3.TabIndex = 37;
            this.label3.Text = "Queries";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(68, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(134, 24);
            this.label2.TabIndex = 28;
            this.label2.Text = "Expenditures";
            // 
            // BtnSave
            // 
            this.BtnSave.BorderRadius = 17;
            this.BtnSave.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.BtnSave.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.BtnSave.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.BtnSave.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.BtnSave.FillColor = System.Drawing.Color.Black;
            this.BtnSave.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.BtnSave.ForeColor = System.Drawing.Color.White;
            this.BtnSave.Location = new System.Drawing.Point(20, 201);
            this.BtnSave.Name = "BtnSave";
            this.BtnSave.Size = new System.Drawing.Size(239, 33);
            this.BtnSave.TabIndex = 37;
            this.BtnSave.Text = "Save";
            this.BtnSave.Click += new System.EventHandler(this.BtnSave_Click);
            // 
            // empidComboBox
            // 
            this.empidComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.expenditureBindingSource, "Empid", true));
            this.empidComboBox.DataSource = this.employeeTblBindingSource;
            this.empidComboBox.DisplayMember = "EmpID";
            this.empidComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.empidComboBox.FormattingEnabled = true;
            this.empidComboBox.Location = new System.Drawing.Point(21, 103);
            this.empidComboBox.Name = "empidComboBox";
            this.empidComboBox.Size = new System.Drawing.Size(96, 24);
            this.empidComboBox.TabIndex = 34;
            this.empidComboBox.ValueMember = "EmpID";
            // 
            // employeeTblBindingSource
            // 
            this.employeeTblBindingSource.DataMember = "EmployeeTbl";
            this.employeeTblBindingSource.DataSource = this.dairymanagementDataSet;
            // 
            // expDateDateTimePicker
            // 
            this.expDateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.expenditureBindingSource, "ExpDate", true));
            this.expDateDateTimePicker.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.expDateDateTimePicker.Location = new System.Drawing.Point(20, 44);
            this.expDateDateTimePicker.Name = "expDateDateTimePicker";
            this.expDateDateTimePicker.Size = new System.Drawing.Size(237, 22);
            this.expDateDateTimePicker.TabIndex = 38;
            // 
            // BtnAdd
            // 
            this.BtnAdd.BorderRadius = 17;
            this.BtnAdd.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.BtnAdd.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.BtnAdd.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.BtnAdd.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.BtnAdd.FillColor = System.Drawing.Color.Black;
            this.BtnAdd.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAdd.ForeColor = System.Drawing.Color.White;
            this.BtnAdd.Location = new System.Drawing.Point(21, 147);
            this.BtnAdd.Name = "BtnAdd";
            this.BtnAdd.Size = new System.Drawing.Size(99, 33);
            this.BtnAdd.TabIndex = 31;
            this.BtnAdd.Text = "Add";
            this.BtnAdd.Click += new System.EventHandler(this.BtnAdd_Click);
            // 
            // expPurposeComboBox
            // 
            this.expPurposeComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.expenditureBindingSource, "ExpPurpose", true));
            this.expPurposeComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.expPurposeComboBox.FormattingEnabled = true;
            this.expPurposeComboBox.Items.AddRange(new object[] {
            "Maintanance",
            "Food",
            "Salary",
            "Tax",
            "Other"});
            this.expPurposeComboBox.Location = new System.Drawing.Point(136, 101);
            this.expPurposeComboBox.Name = "expPurposeComboBox";
            this.expPurposeComboBox.Size = new System.Drawing.Size(121, 24);
            this.expPurposeComboBox.TabIndex = 39;
            // 
            // expAmountTextBox
            // 
            this.expAmountTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.expenditureBindingSource, "ExpAmount", true));
            this.expAmountTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.expAmountTextBox.Location = new System.Drawing.Point(135, 156);
            this.expAmountTextBox.Name = "expAmountTextBox";
            this.expAmountTextBox.Size = new System.Drawing.Size(121, 24);
            this.expAmountTextBox.TabIndex = 40;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(12, 88);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(960, 10);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 26;
            this.pictureBox2.TabStop = false;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.pictureBox4);
            this.groupBox5.Controls.Add(this.pictureBox1);
            this.groupBox5.Location = new System.Drawing.Point(9, 572);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(295, 71);
            this.groupBox5.TabIndex = 36;
            this.groupBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(6, 18);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(49, 47);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 38;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(17, 18);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.pictureBox1.Size = new System.Drawing.Size(99, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 38;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Algerian", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(322, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(355, 54);
            this.label1.TabIndex = 24;
            this.label1.Text = "FARM FINANCE";
            // 
            // employeeTblTableAdapter
            // 
            this.employeeTblTableAdapter.ClearBeforeFill = true;
            // 
            // expenditureTableAdapter
            // 
            this.expenditureTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.BreedTblTableAdapter = null;
            this.tableAdapterManager.CowTblTableAdapter = null;
            this.tableAdapterManager.EmployeeTblTableAdapter = this.employeeTblTableAdapter;
            this.tableAdapterManager.ExpenditureTableAdapter = this.expenditureTableAdapter;
            this.tableAdapterManager.HealthTblTableAdapter = null;
            this.tableAdapterManager.IncomeTblTableAdapter = this.incomeTblTableAdapter;
            this.tableAdapterManager.MilkproductionTblTableAdapter = null;
            this.tableAdapterManager.MilkSalesTblTableAdapter = this.milkSalesTblTableAdapter;
            this.tableAdapterManager.UpdateOrder = DFMS.dairymanagementDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // incomeTblTableAdapter
            // 
            this.incomeTblTableAdapter.ClearBeforeFill = true;
            // 
            // milkSalesTblTableAdapter
            // 
            this.milkSalesTblTableAdapter.ClearBeforeFill = true;
            // 
            // incomeTblBindingSource
            // 
            this.incomeTblBindingSource.DataMember = "IncomeTbl";
            this.incomeTblBindingSource.DataSource = this.dairymanagementDataSet;
            // 
            // formFinance
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(988, 657);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "formFinance";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "formFinance";
            this.Load += new System.EventHandler(this.formFinance_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.expenditureDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.expenditureBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dairymanagementDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.milkSalesTblDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.milkSalesTblBindingSource)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.employIDToolStrip.ResumeLayout(false);
            this.employIDToolStrip.PerformLayout();
            this.purposeToolStrip.ResumeLayout(false);
            this.purposeToolStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.employeeTblBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBox5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.incomeTblBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private Guna.UI2.WinForms.Guna2Button BtnSave;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private Guna.UI2.WinForms.Guna2Button BtnAdd;
        private dairymanagementDataSet dairymanagementDataSet;
        private System.Windows.Forms.BindingSource employeeTblBindingSource;
        private dairymanagementDataSetTableAdapters.EmployeeTblTableAdapter employeeTblTableAdapter;
        private System.Windows.Forms.BindingSource expenditureBindingSource;
        private dairymanagementDataSetTableAdapters.ExpenditureTableAdapter expenditureTableAdapter;
        private dairymanagementDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.ComboBox empidComboBox;
        private System.Windows.Forms.DataGridView expenditureDataGridView;
        private System.Windows.Forms.TextBox expAmountTextBox;
        private System.Windows.Forms.ComboBox expPurposeComboBox;
        private System.Windows.Forms.DateTimePicker expDateDateTimePicker;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private dairymanagementDataSetTableAdapters.IncomeTblTableAdapter incomeTblTableAdapter;
        private System.Windows.Forms.BindingSource incomeTblBindingSource;
        private dairymanagementDataSetTableAdapters.MilkSalesTblTableAdapter milkSalesTblTableAdapter;
        private System.Windows.Forms.BindingSource milkSalesTblBindingSource;
        private System.Windows.Forms.DataGridView milkSalesTblDataGridView;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ToolStrip purposeToolStrip;
        private System.Windows.Forms.ToolStripLabel expPurposeToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox expPurposeToolStripTextBox;
        private System.Windows.Forms.ToolStripButton purposeToolStripButton;
        private System.Windows.Forms.ToolStrip employIDToolStrip;
        private System.Windows.Forms.ToolStripLabel empidToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox empidToolStripTextBox;
        private System.Windows.Forms.ToolStripButton employIDToolStripButton;
    }
}
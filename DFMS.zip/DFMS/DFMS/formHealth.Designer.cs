﻿namespace DFMS
{
    partial class formHealth
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label cow_idLabel;
            System.Windows.Forms.Label vac_DateLabel;
            System.Windows.Forms.Label eventLabel;
            System.Windows.Forms.Label dignosisLabel;
            System.Windows.Forms.Label treatmentLabel;
            System.Windows.Forms.Label costLabel;
            System.Windows.Forms.Label vetNameLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formHealth));
            this.dairymanagementDataSet = new DFMS.dairymanagementDataSet();
            this.healthTblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.healthTblTableAdapter = new DFMS.dairymanagementDataSetTableAdapters.HealthTblTableAdapter();
            this.tableAdapterManager = new DFMS.dairymanagementDataSetTableAdapters.TableAdapterManager();
            this.cow_idComboBox = new System.Windows.Forms.ComboBox();
            this.cowTblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.vac_DateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.eventTextBox = new System.Windows.Forms.TextBox();
            this.dignosisTextBox = new System.Windows.Forms.TextBox();
            this.treatmentTextBox = new System.Windows.Forms.TextBox();
            this.costTextBox = new System.Windows.Forms.TextBox();
            this.vetNameTextBox = new System.Windows.Forms.TextBox();
            this.healthTblDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.BtnExit = new Guna.UI2.WinForms.Guna2Button();
            this.Btnback = new Guna.UI2.WinForms.Guna2Button();
            this.BtnDelete = new Guna.UI2.WinForms.Guna2Button();
            this.BtnAdd = new Guna.UI2.WinForms.Guna2Button();
            this.BtnSave = new Guna.UI2.WinForms.Guna2Button();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cowTblTableAdapter = new DFMS.dairymanagementDataSetTableAdapters.CowTblTableAdapter();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            cow_idLabel = new System.Windows.Forms.Label();
            vac_DateLabel = new System.Windows.Forms.Label();
            eventLabel = new System.Windows.Forms.Label();
            dignosisLabel = new System.Windows.Forms.Label();
            treatmentLabel = new System.Windows.Forms.Label();
            costLabel = new System.Windows.Forms.Label();
            vetNameLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dairymanagementDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.healthTblBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cowTblBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.healthTblDataGridView)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // cow_idLabel
            // 
            cow_idLabel.AutoSize = true;
            cow_idLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            cow_idLabel.Location = new System.Drawing.Point(9, 19);
            cow_idLabel.Name = "cow_idLabel";
            cow_idLabel.Size = new System.Drawing.Size(58, 16);
            cow_idLabel.TabIndex = 1;
            cow_idLabel.Text = "Cow id:";
            // 
            // vac_DateLabel
            // 
            vac_DateLabel.AutoSize = true;
            vac_DateLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            vac_DateLabel.Location = new System.Drawing.Point(9, 55);
            vac_DateLabel.Name = "vac_DateLabel";
            vac_DateLabel.Size = new System.Drawing.Size(76, 16);
            vac_DateLabel.TabIndex = 3;
            vac_DateLabel.Text = "Vac Date:";
            // 
            // eventLabel
            // 
            eventLabel.AutoSize = true;
            eventLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            eventLabel.Location = new System.Drawing.Point(9, 89);
            eventLabel.Name = "eventLabel";
            eventLabel.Size = new System.Drawing.Size(51, 16);
            eventLabel.TabIndex = 5;
            eventLabel.Text = "Event:";
            // 
            // dignosisLabel
            // 
            dignosisLabel.AutoSize = true;
            dignosisLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dignosisLabel.Location = new System.Drawing.Point(9, 126);
            dignosisLabel.Name = "dignosisLabel";
            dignosisLabel.Size = new System.Drawing.Size(73, 16);
            dignosisLabel.TabIndex = 7;
            dignosisLabel.Text = "Dignosis:";
            // 
            // treatmentLabel
            // 
            treatmentLabel.AutoSize = true;
            treatmentLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            treatmentLabel.Location = new System.Drawing.Point(314, 24);
            treatmentLabel.Name = "treatmentLabel";
            treatmentLabel.Size = new System.Drawing.Size(82, 16);
            treatmentLabel.TabIndex = 9;
            treatmentLabel.Text = "Treatment:";
            // 
            // costLabel
            // 
            costLabel.AutoSize = true;
            costLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            costLabel.Location = new System.Drawing.Point(314, 59);
            costLabel.Name = "costLabel";
            costLabel.Size = new System.Drawing.Size(43, 16);
            costLabel.TabIndex = 11;
            costLabel.Text = "Cost:";
            // 
            // vetNameLabel
            // 
            vetNameLabel.AutoSize = true;
            vetNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            vetNameLabel.Location = new System.Drawing.Point(314, 92);
            vetNameLabel.Name = "vetNameLabel";
            vetNameLabel.Size = new System.Drawing.Size(80, 16);
            vetNameLabel.TabIndex = 13;
            vetNameLabel.Text = "Vet Name:";
            // 
            // dairymanagementDataSet
            // 
            this.dairymanagementDataSet.DataSetName = "dairymanagementDataSet";
            this.dairymanagementDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // healthTblBindingSource
            // 
            this.healthTblBindingSource.DataMember = "HealthTbl";
            this.healthTblBindingSource.DataSource = this.dairymanagementDataSet;
            // 
            // healthTblTableAdapter
            // 
            this.healthTblTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.BreedTblTableAdapter = null;
            this.tableAdapterManager.CowTblTableAdapter = null;
            this.tableAdapterManager.EmployeeTblTableAdapter = null;
            this.tableAdapterManager.ExpenditureTableAdapter = null;
            this.tableAdapterManager.HealthTblTableAdapter = this.healthTblTableAdapter;
            this.tableAdapterManager.IncomeTblTableAdapter = null;
            this.tableAdapterManager.MilkproductionTblTableAdapter = null;
            this.tableAdapterManager.MilkSalesTblTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = DFMS.dairymanagementDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // cow_idComboBox
            // 
            this.cow_idComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.healthTblBindingSource, "Cow_id", true));
            this.cow_idComboBox.DataSource = this.cowTblBindingSource;
            this.cow_idComboBox.DisplayMember = "CowID";
            this.cow_idComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cow_idComboBox.FormattingEnabled = true;
            this.cow_idComboBox.Location = new System.Drawing.Point(87, 19);
            this.cow_idComboBox.Name = "cow_idComboBox";
            this.cow_idComboBox.Size = new System.Drawing.Size(210, 23);
            this.cow_idComboBox.TabIndex = 2;
            this.cow_idComboBox.ValueMember = "CowID";
            // 
            // cowTblBindingSource
            // 
            this.cowTblBindingSource.DataMember = "CowTbl";
            this.cowTblBindingSource.DataSource = this.dairymanagementDataSet;
            // 
            // vac_DateDateTimePicker
            // 
            this.vac_DateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.healthTblBindingSource, "Vac_Date", true));
            this.vac_DateDateTimePicker.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vac_DateDateTimePicker.Location = new System.Drawing.Point(87, 54);
            this.vac_DateDateTimePicker.Name = "vac_DateDateTimePicker";
            this.vac_DateDateTimePicker.Size = new System.Drawing.Size(210, 21);
            this.vac_DateDateTimePicker.TabIndex = 4;
            // 
            // eventTextBox
            // 
            this.eventTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.healthTblBindingSource, "Event", true));
            this.eventTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eventTextBox.Location = new System.Drawing.Point(87, 89);
            this.eventTextBox.Name = "eventTextBox";
            this.eventTextBox.Size = new System.Drawing.Size(210, 21);
            this.eventTextBox.TabIndex = 6;
            // 
            // dignosisTextBox
            // 
            this.dignosisTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.healthTblBindingSource, "Dignosis", true));
            this.dignosisTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dignosisTextBox.Location = new System.Drawing.Point(87, 126);
            this.dignosisTextBox.Name = "dignosisTextBox";
            this.dignosisTextBox.Size = new System.Drawing.Size(210, 21);
            this.dignosisTextBox.TabIndex = 8;
            // 
            // treatmentTextBox
            // 
            this.treatmentTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.healthTblBindingSource, "Treatment", true));
            this.treatmentTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.treatmentTextBox.Location = new System.Drawing.Point(402, 21);
            this.treatmentTextBox.Name = "treatmentTextBox";
            this.treatmentTextBox.Size = new System.Drawing.Size(222, 21);
            this.treatmentTextBox.TabIndex = 10;
            // 
            // costTextBox
            // 
            this.costTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.healthTblBindingSource, "Cost", true));
            this.costTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.costTextBox.Location = new System.Drawing.Point(402, 56);
            this.costTextBox.Name = "costTextBox";
            this.costTextBox.Size = new System.Drawing.Size(222, 21);
            this.costTextBox.TabIndex = 12;
            // 
            // vetNameTextBox
            // 
            this.vetNameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.healthTblBindingSource, "VetName", true));
            this.vetNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vetNameTextBox.Location = new System.Drawing.Point(402, 89);
            this.vetNameTextBox.Name = "vetNameTextBox";
            this.vetNameTextBox.Size = new System.Drawing.Size(222, 21);
            this.vetNameTextBox.TabIndex = 14;
            // 
            // healthTblDataGridView
            // 
            this.healthTblDataGridView.AutoGenerateColumns = false;
            this.healthTblDataGridView.BackgroundColor = System.Drawing.Color.White;
            this.healthTblDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.healthTblDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7});
            this.healthTblDataGridView.DataSource = this.healthTblBindingSource;
            this.healthTblDataGridView.Location = new System.Drawing.Point(6, 316);
            this.healthTblDataGridView.Name = "healthTblDataGridView";
            this.healthTblDataGridView.Size = new System.Drawing.Size(945, 264);
            this.healthTblDataGridView.TabIndex = 15;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Cow_id";
            this.dataGridViewTextBoxColumn1.HeaderText = "Cow_id";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Vac_Date";
            this.dataGridViewTextBoxColumn2.HeaderText = "Vac_Date";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Event";
            this.dataGridViewTextBoxColumn3.HeaderText = "Event";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Dignosis";
            this.dataGridViewTextBoxColumn4.HeaderText = "Dignosis";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Treatment";
            this.dataGridViewTextBoxColumn5.HeaderText = "Treatment";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Cost";
            this.dataGridViewTextBoxColumn6.HeaderText = "Cost";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn7.DataPropertyName = "VetName";
            this.dataGridViewTextBoxColumn7.HeaderText = "VetName";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Controls.Add(this.pictureBox3);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Controls.Add(this.pictureBox2);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.healthTblDataGridView);
            this.groupBox1.Location = new System.Drawing.Point(3, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(957, 594);
            this.groupBox1.TabIndex = 16;
            this.groupBox1.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(6, 279);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(945, 31);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 25;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(6, 83);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(945, 10);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 24;
            this.pictureBox2.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.BtnExit);
            this.groupBox3.Controls.Add(this.Btnback);
            this.groupBox3.Controls.Add(this.BtnDelete);
            this.groupBox3.Controls.Add(this.BtnAdd);
            this.groupBox3.Controls.Add(this.BtnSave);
            this.groupBox3.Location = new System.Drawing.Point(664, 99);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(287, 157);
            this.groupBox3.TabIndex = 23;
            this.groupBox3.TabStop = false;
            // 
            // BtnExit
            // 
            this.BtnExit.BorderRadius = 17;
            this.BtnExit.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.BtnExit.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.BtnExit.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.BtnExit.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.BtnExit.FillColor = System.Drawing.Color.Black;
            this.BtnExit.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnExit.ForeColor = System.Drawing.Color.White;
            this.BtnExit.Location = new System.Drawing.Point(157, 109);
            this.BtnExit.Name = "BtnExit";
            this.BtnExit.Size = new System.Drawing.Size(106, 36);
            this.BtnExit.TabIndex = 24;
            this.BtnExit.Text = "Exit";
            this.BtnExit.Click += new System.EventHandler(this.BtnExit_Click);
            // 
            // Btnback
            // 
            this.Btnback.BorderRadius = 17;
            this.Btnback.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.Btnback.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.Btnback.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.Btnback.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.Btnback.FillColor = System.Drawing.Color.Black;
            this.Btnback.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btnback.ForeColor = System.Drawing.Color.White;
            this.Btnback.Location = new System.Drawing.Point(157, 61);
            this.Btnback.Name = "Btnback";
            this.Btnback.Size = new System.Drawing.Size(106, 36);
            this.Btnback.TabIndex = 23;
            this.Btnback.Text = "Back";
            this.Btnback.Click += new System.EventHandler(this.Btnback_Click);
            // 
            // BtnDelete
            // 
            this.BtnDelete.BorderRadius = 17;
            this.BtnDelete.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.BtnDelete.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.BtnDelete.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.BtnDelete.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.BtnDelete.FillColor = System.Drawing.Color.Black;
            this.BtnDelete.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnDelete.ForeColor = System.Drawing.Color.White;
            this.BtnDelete.Location = new System.Drawing.Point(24, 109);
            this.BtnDelete.Name = "BtnDelete";
            this.BtnDelete.Size = new System.Drawing.Size(106, 36);
            this.BtnDelete.TabIndex = 18;
            this.BtnDelete.Text = "Delete";
            this.BtnDelete.Click += new System.EventHandler(this.BtnDelete_Click);
            // 
            // BtnAdd
            // 
            this.BtnAdd.BorderRadius = 17;
            this.BtnAdd.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.BtnAdd.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.BtnAdd.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.BtnAdd.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.BtnAdd.FillColor = System.Drawing.Color.Black;
            this.BtnAdd.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAdd.ForeColor = System.Drawing.Color.White;
            this.BtnAdd.Location = new System.Drawing.Point(24, 17);
            this.BtnAdd.Name = "BtnAdd";
            this.BtnAdd.Size = new System.Drawing.Size(239, 33);
            this.BtnAdd.TabIndex = 17;
            this.BtnAdd.Text = "Add";
            this.BtnAdd.Click += new System.EventHandler(this.BtnAdd_Click);
            // 
            // BtnSave
            // 
            this.BtnSave.BorderRadius = 17;
            this.BtnSave.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.BtnSave.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.BtnSave.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.BtnSave.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.BtnSave.FillColor = System.Drawing.Color.Black;
            this.BtnSave.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSave.ForeColor = System.Drawing.Color.White;
            this.BtnSave.Location = new System.Drawing.Point(24, 61);
            this.BtnSave.Name = "BtnSave";
            this.BtnSave.Size = new System.Drawing.Size(106, 36);
            this.BtnSave.TabIndex = 16;
            this.BtnSave.Text = "Save";
            this.BtnSave.Click += new System.EventHandler(this.BtnSave_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Algerian", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(318, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(312, 54);
            this.label1.TabIndex = 22;
            this.label1.Text = "HEALTH FILE";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dignosisTextBox);
            this.groupBox2.Controls.Add(this.cow_idComboBox);
            this.groupBox2.Controls.Add(this.vetNameTextBox);
            this.groupBox2.Controls.Add(dignosisLabel);
            this.groupBox2.Controls.Add(vetNameLabel);
            this.groupBox2.Controls.Add(this.eventTextBox);
            this.groupBox2.Controls.Add(this.costTextBox);
            this.groupBox2.Controls.Add(eventLabel);
            this.groupBox2.Controls.Add(costLabel);
            this.groupBox2.Controls.Add(cow_idLabel);
            this.groupBox2.Controls.Add(this.treatmentTextBox);
            this.groupBox2.Controls.Add(this.vac_DateDateTimePicker);
            this.groupBox2.Controls.Add(treatmentLabel);
            this.groupBox2.Controls.Add(vac_DateLabel);
            this.groupBox2.Location = new System.Drawing.Point(6, 97);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(652, 157);
            this.groupBox2.TabIndex = 21;
            this.groupBox2.TabStop = false;
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // cowTblTableAdapter
            // 
            this.cowTblTableAdapter.ClearBeforeFill = true;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(849, 10);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.pictureBox3.Size = new System.Drawing.Size(102, 67);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 28;
            this.pictureBox3.TabStop = false;
            // 
            // formHealth
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(965, 600);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "formHealth";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "formHealth";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.formHealth_FormClosed);
            this.Load += new System.EventHandler(this.formHealth_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dairymanagementDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.healthTblBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cowTblBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.healthTblDataGridView)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private dairymanagementDataSet dairymanagementDataSet;
        private System.Windows.Forms.BindingSource healthTblBindingSource;
        private dairymanagementDataSetTableAdapters.HealthTblTableAdapter healthTblTableAdapter;
        private dairymanagementDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.ComboBox cow_idComboBox;
        private System.Windows.Forms.DateTimePicker vac_DateDateTimePicker;
        private System.Windows.Forms.TextBox eventTextBox;
        private System.Windows.Forms.TextBox dignosisTextBox;
        private System.Windows.Forms.TextBox treatmentTextBox;
        private System.Windows.Forms.TextBox costTextBox;
        private System.Windows.Forms.TextBox vetNameTextBox;
        private System.Windows.Forms.DataGridView healthTblDataGridView;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox3;
        private Guna.UI2.WinForms.Guna2Button BtnExit;
        private Guna.UI2.WinForms.Guna2Button Btnback;
        private Guna.UI2.WinForms.Guna2Button BtnDelete;
        private Guna.UI2.WinForms.Guna2Button BtnAdd;
        private Guna.UI2.WinForms.Guna2Button BtnSave;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.BindingSource cowTblBindingSource;
        private dairymanagementDataSetTableAdapters.CowTblTableAdapter cowTblTableAdapter;
        private System.Windows.Forms.PictureBox pictureBox3;
    }
}
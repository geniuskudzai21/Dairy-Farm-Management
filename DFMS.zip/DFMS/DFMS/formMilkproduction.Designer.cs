﻿namespace DFMS
{
    partial class formMilkproduction
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label cowIdLabel;
            System.Windows.Forms.Label amMilkLabel;
            System.Windows.Forms.Label noonMilkLabel;
            System.Windows.Forms.Label pmMilkLabel;
            System.Windows.Forms.Label totalMilkLabel;
            System.Windows.Forms.Label dateProdLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formMilkproduction));
            this.dairymanagementDataSet = new DFMS.dairymanagementDataSet();
            this.milkproductionTblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.milkproductionTblTableAdapter = new DFMS.dairymanagementDataSetTableAdapters.MilkproductionTblTableAdapter();
            this.tableAdapterManager = new DFMS.dairymanagementDataSetTableAdapters.TableAdapterManager();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.milkproductionTblDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.BtnExit = new Guna.UI2.WinForms.Guna2Button();
            this.Btnback = new Guna.UI2.WinForms.Guna2Button();
            this.BtnDelete = new Guna.UI2.WinForms.Guna2Button();
            this.BtnAdd = new Guna.UI2.WinForms.Guna2Button();
            this.BtnSave = new Guna.UI2.WinForms.Guna2Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cowIdComboBox = new System.Windows.Forms.ComboBox();
            this.cowTblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.amMilkTextBox = new System.Windows.Forms.TextBox();
            this.noonMilkTextBox = new System.Windows.Forms.TextBox();
            this.pmMilkTextBox = new System.Windows.Forms.TextBox();
            this.totalMilkTextBox = new System.Windows.Forms.TextBox();
            this.dateProdDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.cowTblTableAdapter = new DFMS.dairymanagementDataSetTableAdapters.CowTblTableAdapter();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            cowIdLabel = new System.Windows.Forms.Label();
            amMilkLabel = new System.Windows.Forms.Label();
            noonMilkLabel = new System.Windows.Forms.Label();
            pmMilkLabel = new System.Windows.Forms.Label();
            totalMilkLabel = new System.Windows.Forms.Label();
            dateProdLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dairymanagementDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.milkproductionTblBindingSource)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.milkproductionTblDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cowTblBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // cowIdLabel
            // 
            cowIdLabel.AutoSize = true;
            cowIdLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            cowIdLabel.Location = new System.Drawing.Point(6, 33);
            cowIdLabel.Name = "cowIdLabel";
            cowIdLabel.Size = new System.Drawing.Size(58, 16);
            cowIdLabel.TabIndex = 0;
            cowIdLabel.Text = "Cow Id:";
            // 
            // amMilkLabel
            // 
            amMilkLabel.AutoSize = true;
            amMilkLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            amMilkLabel.Location = new System.Drawing.Point(6, 70);
            amMilkLabel.Name = "amMilkLabel";
            amMilkLabel.Size = new System.Drawing.Size(66, 16);
            amMilkLabel.TabIndex = 2;
            amMilkLabel.Text = "Am Milk:";
            // 
            // noonMilkLabel
            // 
            noonMilkLabel.AutoSize = true;
            noonMilkLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            noonMilkLabel.Location = new System.Drawing.Point(6, 102);
            noonMilkLabel.Name = "noonMilkLabel";
            noonMilkLabel.Size = new System.Drawing.Size(81, 16);
            noonMilkLabel.TabIndex = 4;
            noonMilkLabel.Text = "Noon Milk:";
            // 
            // pmMilkLabel
            // 
            pmMilkLabel.AutoSize = true;
            pmMilkLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            pmMilkLabel.Location = new System.Drawing.Point(316, 33);
            pmMilkLabel.Name = "pmMilkLabel";
            pmMilkLabel.Size = new System.Drawing.Size(66, 16);
            pmMilkLabel.TabIndex = 6;
            pmMilkLabel.Text = "Pm Milk:";
            // 
            // totalMilkLabel
            // 
            totalMilkLabel.AutoSize = true;
            totalMilkLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            totalMilkLabel.Location = new System.Drawing.Point(316, 67);
            totalMilkLabel.Name = "totalMilkLabel";
            totalMilkLabel.Size = new System.Drawing.Size(80, 16);
            totalMilkLabel.TabIndex = 8;
            totalMilkLabel.Text = "Total Milk:";
            // 
            // dateProdLabel
            // 
            dateProdLabel.AutoSize = true;
            dateProdLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dateProdLabel.Location = new System.Drawing.Point(316, 101);
            dateProdLabel.Name = "dateProdLabel";
            dateProdLabel.Size = new System.Drawing.Size(82, 16);
            dateProdLabel.TabIndex = 10;
            dateProdLabel.Text = "Date Prod:";
            // 
            // dairymanagementDataSet
            // 
            this.dairymanagementDataSet.DataSetName = "dairymanagementDataSet";
            this.dairymanagementDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // milkproductionTblBindingSource
            // 
            this.milkproductionTblBindingSource.DataMember = "MilkproductionTbl";
            this.milkproductionTblBindingSource.DataSource = this.dairymanagementDataSet;
            // 
            // milkproductionTblTableAdapter
            // 
            this.milkproductionTblTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.BreedTblTableAdapter = null;
            this.tableAdapterManager.CowTblTableAdapter = null;
            this.tableAdapterManager.EmployeeTblTableAdapter = null;
            this.tableAdapterManager.ExpenditureTableAdapter = null;
            this.tableAdapterManager.HealthTblTableAdapter = null;
            this.tableAdapterManager.IncomeTblTableAdapter = null;
            this.tableAdapterManager.MilkproductionTblTableAdapter = this.milkproductionTblTableAdapter;
            this.tableAdapterManager.MilkSalesTblTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = DFMS.dairymanagementDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Controls.Add(this.pictureBox3);
            this.groupBox1.Controls.Add(this.milkproductionTblDataGridView);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Controls.Add(this.pictureBox2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Location = new System.Drawing.Point(5, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(958, 593);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // milkproductionTblDataGridView
            // 
            this.milkproductionTblDataGridView.AutoGenerateColumns = false;
            this.milkproductionTblDataGridView.BackgroundColor = System.Drawing.Color.White;
            this.milkproductionTblDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.milkproductionTblDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            this.milkproductionTblDataGridView.DataSource = this.milkproductionTblBindingSource;
            this.milkproductionTblDataGridView.Location = new System.Drawing.Point(6, 315);
            this.milkproductionTblDataGridView.Name = "milkproductionTblDataGridView";
            this.milkproductionTblDataGridView.Size = new System.Drawing.Size(937, 265);
            this.milkproductionTblDataGridView.TabIndex = 25;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn1.DataPropertyName = "CowId";
            this.dataGridViewTextBoxColumn1.HeaderText = "CowId";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "AmMilk";
            this.dataGridViewTextBoxColumn2.HeaderText = "AmMilk";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "NoonMilk";
            this.dataGridViewTextBoxColumn3.HeaderText = "NoonMilk";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "PmMilk";
            this.dataGridViewTextBoxColumn4.HeaderText = "PmMilk";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "TotalMilk";
            this.dataGridViewTextBoxColumn5.HeaderText = "TotalMilk";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn6.DataPropertyName = "DateProd";
            this.dataGridViewTextBoxColumn6.HeaderText = "DateProd";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(6, 278);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(937, 31);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 25;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(6, 92);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(934, 10);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 24;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Algerian", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(206, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(528, 54);
            this.label1.TabIndex = 23;
            this.label1.Text = "MILK PRODUCTION FILE";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.BtnExit);
            this.groupBox3.Controls.Add(this.Btnback);
            this.groupBox3.Controls.Add(this.BtnDelete);
            this.groupBox3.Controls.Add(this.BtnAdd);
            this.groupBox3.Controls.Add(this.BtnSave);
            this.groupBox3.Location = new System.Drawing.Point(654, 108);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(286, 157);
            this.groupBox3.TabIndex = 22;
            this.groupBox3.TabStop = false;
            // 
            // BtnExit
            // 
            this.BtnExit.BorderRadius = 17;
            this.BtnExit.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.BtnExit.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.BtnExit.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.BtnExit.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.BtnExit.FillColor = System.Drawing.Color.Black;
            this.BtnExit.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnExit.ForeColor = System.Drawing.Color.White;
            this.BtnExit.Location = new System.Drawing.Point(157, 109);
            this.BtnExit.Name = "BtnExit";
            this.BtnExit.Size = new System.Drawing.Size(106, 36);
            this.BtnExit.TabIndex = 24;
            this.BtnExit.Text = "Exit";
            this.BtnExit.Click += new System.EventHandler(this.BtnExit_Click);
            // 
            // Btnback
            // 
            this.Btnback.BorderRadius = 17;
            this.Btnback.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.Btnback.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.Btnback.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.Btnback.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.Btnback.FillColor = System.Drawing.Color.Black;
            this.Btnback.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btnback.ForeColor = System.Drawing.Color.White;
            this.Btnback.Location = new System.Drawing.Point(157, 61);
            this.Btnback.Name = "Btnback";
            this.Btnback.Size = new System.Drawing.Size(106, 36);
            this.Btnback.TabIndex = 23;
            this.Btnback.Text = "Back";
            this.Btnback.Click += new System.EventHandler(this.Btnback_Click);
            // 
            // BtnDelete
            // 
            this.BtnDelete.BorderRadius = 17;
            this.BtnDelete.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.BtnDelete.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.BtnDelete.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.BtnDelete.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.BtnDelete.FillColor = System.Drawing.Color.Black;
            this.BtnDelete.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnDelete.ForeColor = System.Drawing.Color.White;
            this.BtnDelete.Location = new System.Drawing.Point(24, 109);
            this.BtnDelete.Name = "BtnDelete";
            this.BtnDelete.Size = new System.Drawing.Size(106, 36);
            this.BtnDelete.TabIndex = 18;
            this.BtnDelete.Text = "Delete";
            this.BtnDelete.Click += new System.EventHandler(this.BtnDelete_Click);
            // 
            // BtnAdd
            // 
            this.BtnAdd.BorderRadius = 17;
            this.BtnAdd.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.BtnAdd.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.BtnAdd.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.BtnAdd.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.BtnAdd.FillColor = System.Drawing.Color.Black;
            this.BtnAdd.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAdd.ForeColor = System.Drawing.Color.White;
            this.BtnAdd.Location = new System.Drawing.Point(24, 16);
            this.BtnAdd.Name = "BtnAdd";
            this.BtnAdd.Size = new System.Drawing.Size(239, 33);
            this.BtnAdd.TabIndex = 17;
            this.BtnAdd.Text = "Add";
            this.BtnAdd.Click += new System.EventHandler(this.BtnAdd_Click);
            // 
            // BtnSave
            // 
            this.BtnSave.BorderRadius = 17;
            this.BtnSave.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.BtnSave.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.BtnSave.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.BtnSave.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.BtnSave.FillColor = System.Drawing.Color.Black;
            this.BtnSave.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSave.ForeColor = System.Drawing.Color.White;
            this.BtnSave.Location = new System.Drawing.Point(24, 61);
            this.BtnSave.Name = "BtnSave";
            this.BtnSave.Size = new System.Drawing.Size(106, 36);
            this.BtnSave.TabIndex = 16;
            this.BtnSave.Text = "Save";
            this.BtnSave.Click += new System.EventHandler(this.BtnSave_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(cowIdLabel);
            this.groupBox2.Controls.Add(this.cowIdComboBox);
            this.groupBox2.Controls.Add(amMilkLabel);
            this.groupBox2.Controls.Add(this.amMilkTextBox);
            this.groupBox2.Controls.Add(noonMilkLabel);
            this.groupBox2.Controls.Add(this.noonMilkTextBox);
            this.groupBox2.Controls.Add(pmMilkLabel);
            this.groupBox2.Controls.Add(this.pmMilkTextBox);
            this.groupBox2.Controls.Add(totalMilkLabel);
            this.groupBox2.Controls.Add(this.totalMilkTextBox);
            this.groupBox2.Controls.Add(dateProdLabel);
            this.groupBox2.Controls.Add(this.dateProdDateTimePicker);
            this.groupBox2.Location = new System.Drawing.Point(6, 108);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(642, 157);
            this.groupBox2.TabIndex = 21;
            this.groupBox2.TabStop = false;
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // cowIdComboBox
            // 
            this.cowIdComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.milkproductionTblBindingSource, "CowId", true));
            this.cowIdComboBox.DataSource = this.cowTblBindingSource;
            this.cowIdComboBox.DisplayMember = "CowID";
            this.cowIdComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cowIdComboBox.FormattingEnabled = true;
            this.cowIdComboBox.Location = new System.Drawing.Point(93, 30);
            this.cowIdComboBox.Name = "cowIdComboBox";
            this.cowIdComboBox.Size = new System.Drawing.Size(200, 24);
            this.cowIdComboBox.TabIndex = 1;
            this.cowIdComboBox.ValueMember = "CowID";
            // 
            // cowTblBindingSource
            // 
            this.cowTblBindingSource.DataMember = "CowTbl";
            this.cowTblBindingSource.DataSource = this.dairymanagementDataSet;
            // 
            // amMilkTextBox
            // 
            this.amMilkTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.milkproductionTblBindingSource, "AmMilk", true));
            this.amMilkTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.amMilkTextBox.Location = new System.Drawing.Point(93, 67);
            this.amMilkTextBox.Name = "amMilkTextBox";
            this.amMilkTextBox.Size = new System.Drawing.Size(200, 22);
            this.amMilkTextBox.TabIndex = 3;
            // 
            // noonMilkTextBox
            // 
            this.noonMilkTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.milkproductionTblBindingSource, "NoonMilk", true));
            this.noonMilkTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.noonMilkTextBox.Location = new System.Drawing.Point(93, 99);
            this.noonMilkTextBox.Name = "noonMilkTextBox";
            this.noonMilkTextBox.Size = new System.Drawing.Size(200, 22);
            this.noonMilkTextBox.TabIndex = 5;
            // 
            // pmMilkTextBox
            // 
            this.pmMilkTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.milkproductionTblBindingSource, "PmMilk", true));
            this.pmMilkTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pmMilkTextBox.Location = new System.Drawing.Point(402, 30);
            this.pmMilkTextBox.Name = "pmMilkTextBox";
            this.pmMilkTextBox.Size = new System.Drawing.Size(222, 22);
            this.pmMilkTextBox.TabIndex = 7;
            // 
            // totalMilkTextBox
            // 
            this.totalMilkTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.milkproductionTblBindingSource, "TotalMilk", true));
            this.totalMilkTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalMilkTextBox.Location = new System.Drawing.Point(402, 64);
            this.totalMilkTextBox.Name = "totalMilkTextBox";
            this.totalMilkTextBox.Size = new System.Drawing.Size(222, 22);
            this.totalMilkTextBox.TabIndex = 9;
            // 
            // dateProdDateTimePicker
            // 
            this.dateProdDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.milkproductionTblBindingSource, "DateProd", true));
            this.dateProdDateTimePicker.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateProdDateTimePicker.Location = new System.Drawing.Point(402, 97);
            this.dateProdDateTimePicker.Name = "dateProdDateTimePicker";
            this.dateProdDateTimePicker.Size = new System.Drawing.Size(222, 22);
            this.dateProdDateTimePicker.TabIndex = 11;
            // 
            // cowTblTableAdapter
            // 
            this.cowTblTableAdapter.ClearBeforeFill = true;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(825, 19);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.pictureBox3.Size = new System.Drawing.Size(115, 67);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 28;
            this.pictureBox3.TabStop = false;
            // 
            // formMilkproduction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(968, 603);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "formMilkproduction";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "formMilkproduction";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.formMilkproduction_FormClosed);
            this.Load += new System.EventHandler(this.formMilkproduction_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dairymanagementDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.milkproductionTblBindingSource)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.milkproductionTblDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cowTblBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private dairymanagementDataSet dairymanagementDataSet;
        private System.Windows.Forms.BindingSource milkproductionTblBindingSource;
        private dairymanagementDataSetTableAdapters.MilkproductionTblTableAdapter milkproductionTblTableAdapter;
        private dairymanagementDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private Guna.UI2.WinForms.Guna2Button BtnExit;
        private Guna.UI2.WinForms.Guna2Button Btnback;
        private Guna.UI2.WinForms.Guna2Button BtnDelete;
        private Guna.UI2.WinForms.Guna2Button BtnAdd;
        private Guna.UI2.WinForms.Guna2Button BtnSave;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ComboBox cowIdComboBox;
        private System.Windows.Forms.TextBox amMilkTextBox;
        private System.Windows.Forms.TextBox noonMilkTextBox;
        private System.Windows.Forms.TextBox pmMilkTextBox;
        private System.Windows.Forms.TextBox totalMilkTextBox;
        private System.Windows.Forms.DateTimePicker dateProdDateTimePicker;
        private System.Windows.Forms.DataGridView milkproductionTblDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.BindingSource cowTblBindingSource;
        private dairymanagementDataSetTableAdapters.CowTblTableAdapter cowTblTableAdapter;
        private System.Windows.Forms.PictureBox pictureBox3;
    }
}
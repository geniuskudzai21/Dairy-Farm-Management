﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DFMS
{
    public partial class formCattle : Form
    {
        public formCattle()
        {
            InitializeComponent();
        }


        private void cowTblBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.cowTblBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dairymanagementDataSet);

        }

        private void formCattle_Load(object sender, EventArgs e)
        {
            cattleAge();
            this.cowTblTableAdapter.Fill(this.dairymanagementDataSet.CowTbl);


        }

        private void cattleAge()
        {
            DateTime dob = d_0_BDateTimePicker.Value;
            int age = CalculateAge(dob);
            ageTextBox.Text = age.ToString();
        }
        private int CalculateAge(DateTime dob)
        {
            DateTime today = DateTime.Today;
            int age = today.Year - dob.Year;
            if (today < dob.AddYears(age))
            {
                age--;
            }

            return age;
        }

        private void cowTblDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            this.cowTblBindingSource.AddNew();
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            cattleAge();
            System.Media.SystemSounds.Beep.Play();
            this.cowTblBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dairymanagementDataSet);
            MessageBox.Show("Record Saved successfuly!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
          
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            System.Media.SystemSounds.Beep.Play();
            if (MessageBox.Show("Are you sure you want to delete the record?", "Confirm deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.cowTblBindingSource.RemoveCurrent();
                this.tableAdapterManager.UpdateAll(this.dairymanagementDataSet);
                MessageBox.Show("Record Deleted successfuly!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            System.Media.SystemSounds.Beep.Play();
            if (MessageBox.Show("Are you sure you want to go back?", "Confirm Back", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Form1 menuForm = new Form1();
                menuForm.Show();
                this.Close();
            }
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            System.Media.SystemSounds.Beep.Play();
            if (MessageBox.Show("Are you sure you want to exit?", "Confirm exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}

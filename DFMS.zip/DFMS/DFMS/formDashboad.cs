﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DFMS
{
    public partial class formDashboad : Form
    {
        public formDashboad()
        {
            InitializeComponent();
        }
       
        int employee = 0;
        int totalMilk = 0;
        int count = 0;
        int cow = 0;
        int totalIncome = 0;
        int totalExpenditure = 0;
        int balance = 0;

        private void formDashboad_Load(object sender, EventArgs e)
        {
           
            this.expenditureTableAdapter.Fill(this.dairymanagementDataSet.Expenditure);

            this.cowTblTableAdapter.Fill(this.dairymanagementDataSet.CowTbl);
            
            this.milkSalesTblTableAdapter.Fill(this.dairymanagementDataSet.MilkSalesTbl);

            this.employeeTblTableAdapter.Fill(this.dairymanagementDataSet.EmployeeTbl);
            this.ControlBox = false;

            NumberOfEmployees();
            milkStock();
            NumberOfCows();
            totalInCome();
            totalExp();
            totalBalance();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            System.Media.SystemSounds.Beep.Play();
            if (MessageBox.Show("Are you sure you want to exit?", "Confirm exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

      

        private void guna2GroupBox1_Click(object sender, EventArgs e)
        {

        }
        private void NumberOfEmployees()
        {
            foreach (DataGridViewRow row in employeeTblDataGridView.Rows)
            {
                if (row.Cells[0].Value != null)
                {
                    employee++;
                }
                if (employee > 0)
                {
                    lblEmployees.Text = employee.ToString();
                }
                else
                {
                    lblEmployees.Text = "0";
                }
            }
        }
        public void milkStock()
        {
            foreach (DataGridViewRow row in milkSalesTblDataGridView.Rows)
            {
                if (row.Cells[5].Value != null)
                {
                    int milk = Convert.ToInt32(row.Cells[5].Value);
                    totalMilk += milk;
                    count++;
                }
                if (count > 0)
                {
                    lblTotalMilk.Text = totalMilk.ToString() + " L";
                }
                else
                {
                    lblTotalMilk.Text = "0";
                }
            }
        }
        private void NumberOfCows()
        {
            foreach (DataGridViewRow row in cowTblDataGridView.Rows)
            {
                if (row.Cells[0].Value != null)
                {
                    cow++;
                }
                if (cow > 0)
                {
                    lblCows.Text = cow.ToString();
                }
                else
                {
                    lblCows.Text = "0";
                }
            }
        }
        public void totalInCome()
        {
            foreach (DataGridViewRow row in milkSalesTblDataGridView.Rows)
            {
                if (row.Cells[6].Value != null)
                {
                    int income = Convert.ToInt32(row.Cells[6].Value);
                    totalIncome += income;
                    count++;
                }
                if (count > 0)
                {
                    lblTotalIncome.Text = "$ "+totalIncome.ToString();
                }
                else
                {
                    lblTotalIncome.Text = "0";
                }
            }
        }
        public void totalExp()
        {
            foreach (DataGridViewRow row in expenditureDataGridView.Rows)
            {
                if (row.Cells[3].Value != null)
                {
                    int exp = Convert.ToInt32(row.Cells[3].Value);
                    totalExpenditure += exp;
                    count++;
                }
                if (count > 0)
                {
                    lblExpenditure.Text = "$ " + totalExpenditure.ToString();
                }
                else
                {
                    lblExpenditure.Text = "0";
                }
            }
        }
        public void totalBalance()
        {
            balance = totalIncome - totalExpenditure;
            lblBalance.Text = "$ "+balance.ToString();
        }


        private void employeeTblBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.employeeTblBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dairymanagementDataSet);

        }


        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            System.Media.SystemSounds.Beep.Play();
            if (MessageBox.Show("Are you sure you want to go back?", "Confirm Back", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Form1 menuForm = new Form1();
                menuForm.Show();
                this.Close();
            }
        }

    }
}

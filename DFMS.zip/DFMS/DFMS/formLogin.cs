﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DFMS
{
    public partial class formLogin : Form
    {
        public formLogin()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                txtPassword.PasswordChar = '\0';
            }
            else
            {
                txtPassword.PasswordChar = '*';
            }
        }
      
        private void BtnLogin_Click(object sender, EventArgs e)
        {
            if (optionCombobox.Text == "Admin")
            {
               if(txtUsername.Text == "admin" && txtPassword.Text == "12345")
                {
                    MessageBox.Show("Login successful", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    formEmployees employee = new formEmployees();
                    employee.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Login failed", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if(optionCombobox.Text == "Employee")
            {
             
                if (string.IsNullOrEmpty(txtUsername.Text))
                {
                    MessageBox.Show("Please enter your username.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtUsername.Focus();
                    return;
                }
                try
                {
                    dairymanagementDataSetTableAdapters.EmployeeTblTableAdapter employee = new dairymanagementDataSetTableAdapters.EmployeeTblTableAdapter();
                    dairymanagementDataSet.EmployeeTblDataTable dt = employee.GetDataByEmpNameEmpID(txtUsername.Text, int.Parse(txtPassword.Text));
                    if (dt.Rows.Count > 0)
                    {
                        MessageBox.Show("Login successful", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        Form1 menu = new Form1();
                        menu.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Login failed", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Login failed", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            
        }

        private void txtUsername_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                txtPassword.Focus();
            }

        }

        private void txtPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                txtPassword.Focus();
            }
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            System.Media.SystemSounds.Beep.Play();
            if (MessageBox.Show("Are you sure you want to exit?", "Confirm exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
    
}

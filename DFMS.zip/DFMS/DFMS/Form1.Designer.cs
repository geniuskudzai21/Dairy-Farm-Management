﻿namespace DFMS
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.sidebarTransition = new System.Windows.Forms.Timer(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.BtnMilkproduction = new System.Windows.Forms.Button();
            this.Btnmilksales = new System.Windows.Forms.Button();
            this.BtnFinance = new System.Windows.Forms.Button();
            this.BtnBreeding = new System.Windows.Forms.Button();
            this.BtnHealth = new System.Windows.Forms.Button();
            this.BtnDashboard = new System.Windows.Forms.Button();
            this.BtnCattle = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // sidebarTransition
            // 
            this.sidebarTransition.Interval = 10;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(315, 139);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(501, 370);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // BtnMilkproduction
            // 
            this.BtnMilkproduction.BackColor = System.Drawing.Color.White;
            this.BtnMilkproduction.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnMilkproduction.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnMilkproduction.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnMilkproduction.ForeColor = System.Drawing.Color.Black;
            this.BtnMilkproduction.Image = ((System.Drawing.Image)(resources.GetObject("BtnMilkproduction.Image")));
            this.BtnMilkproduction.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnMilkproduction.Location = new System.Drawing.Point(6, 206);
            this.BtnMilkproduction.Name = "BtnMilkproduction";
            this.BtnMilkproduction.Size = new System.Drawing.Size(208, 48);
            this.BtnMilkproduction.TabIndex = 10;
            this.BtnMilkproduction.Text = "Milk Production";
            this.BtnMilkproduction.UseVisualStyleBackColor = false;
            this.BtnMilkproduction.Click += new System.EventHandler(this.BtnMilkproduction_Click);
            // 
            // Btnmilksales
            // 
            this.Btnmilksales.BackColor = System.Drawing.Color.White;
            this.Btnmilksales.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btnmilksales.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Btnmilksales.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btnmilksales.ForeColor = System.Drawing.Color.Black;
            this.Btnmilksales.Image = ((System.Drawing.Image)(resources.GetObject("Btnmilksales.Image")));
            this.Btnmilksales.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Btnmilksales.Location = new System.Drawing.Point(6, 260);
            this.Btnmilksales.Name = "Btnmilksales";
            this.Btnmilksales.Size = new System.Drawing.Size(208, 48);
            this.Btnmilksales.TabIndex = 11;
            this.Btnmilksales.Text = "Milk Sales";
            this.Btnmilksales.UseVisualStyleBackColor = false;
            this.Btnmilksales.Click += new System.EventHandler(this.Btnmilksales_Click);
            // 
            // BtnFinance
            // 
            this.BtnFinance.BackColor = System.Drawing.Color.White;
            this.BtnFinance.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnFinance.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnFinance.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnFinance.ForeColor = System.Drawing.Color.Black;
            this.BtnFinance.Image = ((System.Drawing.Image)(resources.GetObject("BtnFinance.Image")));
            this.BtnFinance.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnFinance.Location = new System.Drawing.Point(6, 314);
            this.BtnFinance.Name = "BtnFinance";
            this.BtnFinance.Size = new System.Drawing.Size(208, 48);
            this.BtnFinance.TabIndex = 12;
            this.BtnFinance.Text = "Finance";
            this.BtnFinance.UseVisualStyleBackColor = false;
            this.BtnFinance.Click += new System.EventHandler(this.BtnFinance_Click);
            // 
            // BtnBreeding
            // 
            this.BtnBreeding.BackColor = System.Drawing.Color.White;
            this.BtnBreeding.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnBreeding.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnBreeding.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnBreeding.ForeColor = System.Drawing.Color.Black;
            this.BtnBreeding.Image = ((System.Drawing.Image)(resources.GetObject("BtnBreeding.Image")));
            this.BtnBreeding.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnBreeding.Location = new System.Drawing.Point(6, 98);
            this.BtnBreeding.Name = "BtnBreeding";
            this.BtnBreeding.Size = new System.Drawing.Size(208, 48);
            this.BtnBreeding.TabIndex = 13;
            this.BtnBreeding.Text = "Breeding";
            this.BtnBreeding.UseVisualStyleBackColor = false;
            this.BtnBreeding.Click += new System.EventHandler(this.BtnBreeding_Click);
            // 
            // BtnHealth
            // 
            this.BtnHealth.BackColor = System.Drawing.Color.White;
            this.BtnHealth.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnHealth.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnHealth.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnHealth.ForeColor = System.Drawing.Color.Black;
            this.BtnHealth.Image = ((System.Drawing.Image)(resources.GetObject("BtnHealth.Image")));
            this.BtnHealth.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnHealth.Location = new System.Drawing.Point(6, 152);
            this.BtnHealth.Name = "BtnHealth";
            this.BtnHealth.Size = new System.Drawing.Size(208, 48);
            this.BtnHealth.TabIndex = 14;
            this.BtnHealth.Text = "Health";
            this.BtnHealth.UseVisualStyleBackColor = false;
            this.BtnHealth.Click += new System.EventHandler(this.BtnHealth_Click);
            // 
            // BtnDashboard
            // 
            this.BtnDashboard.BackColor = System.Drawing.Color.White;
            this.BtnDashboard.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnDashboard.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnDashboard.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnDashboard.ForeColor = System.Drawing.Color.Black;
            this.BtnDashboard.Image = ((System.Drawing.Image)(resources.GetObject("BtnDashboard.Image")));
            this.BtnDashboard.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnDashboard.Location = new System.Drawing.Point(6, 368);
            this.BtnDashboard.Name = "BtnDashboard";
            this.BtnDashboard.Size = new System.Drawing.Size(208, 48);
            this.BtnDashboard.TabIndex = 15;
            this.BtnDashboard.Text = "Dashboard";
            this.BtnDashboard.UseVisualStyleBackColor = false;
            this.BtnDashboard.Click += new System.EventHandler(this.BtnDashboard_Click);
            // 
            // BtnCattle
            // 
            this.BtnCattle.BackColor = System.Drawing.Color.White;
            this.BtnCattle.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnCattle.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnCattle.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnCattle.ForeColor = System.Drawing.Color.Black;
            this.BtnCattle.Image = ((System.Drawing.Image)(resources.GetObject("BtnCattle.Image")));
            this.BtnCattle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnCattle.Location = new System.Drawing.Point(6, 44);
            this.BtnCattle.Name = "BtnCattle";
            this.BtnCattle.Size = new System.Drawing.Size(208, 48);
            this.BtnCattle.TabIndex = 16;
            this.BtnCattle.Text = "       Cattle";
            this.BtnCattle.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnCattle.UseVisualStyleBackColor = false;
            this.BtnCattle.Click += new System.EventHandler(this.BtnCattle_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Location = new System.Drawing.Point(0, 64);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(247, 528);
            this.panel1.TabIndex = 26;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(0, 0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(259, 10);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 30;
            this.pictureBox3.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.BtnDashboard);
            this.groupBox1.Controls.Add(this.BtnCattle);
            this.groupBox1.Controls.Add(this.BtnMilkproduction);
            this.groupBox1.Controls.Add(this.BtnBreeding);
            this.groupBox1.Controls.Add(this.Btnmilksales);
            this.groupBox1.Controls.Add(this.BtnHealth);
            this.groupBox1.Controls.Add(this.BtnFinance);
            this.groupBox1.Location = new System.Drawing.Point(12, 31);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(222, 426);
            this.groupBox1.TabIndex = 30;
            this.groupBox1.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(55, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(113, 27);
            this.label6.TabIndex = 29;
            this.label6.Text = "Form Panel";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(985, 64);
            this.panel2.TabIndex = 28;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Algerian", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(32, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(188, 54);
            this.label1.TabIndex = 25;
            this.label1.Text = "ZUBBY ";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(894, 5);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(79, 59);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 24;
            this.pictureBox2.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Algerian", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(309, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(499, 32);
            this.label2.TabIndex = 19;
            this.label2.Text = "DAIRY FARM MANAGEMENT SYSTEM";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.pictureBox5);
            this.panel3.Controls.Add(this.pictureBox4);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 527);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(985, 64);
            this.panel3.TabIndex = 29;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(447, 39);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(117, 16);
            this.label4.TabIndex = 31;
            this.label4.Text = "ZUBBY DFMS 2024";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(879, 23);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 27);
            this.label5.TabIndex = 30;
            this.label5.Text = "Exit";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(47, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 27);
            this.label3.TabIndex = 28;
            this.label3.Text = "LoggOff";
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(12, 16);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(43, 46);
            this.pictureBox5.TabIndex = 25;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(934, 16);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(39, 36);
            this.pictureBox4.TabIndex = 24;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(985, 591);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Timer sidebarTransition;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button BtnMilkproduction;
        private System.Windows.Forms.Button Btnmilksales;
        private System.Windows.Forms.Button BtnFinance;
        private System.Windows.Forms.Button BtnBreeding;
        private System.Windows.Forms.Button BtnHealth;
        private System.Windows.Forms.Button BtnDashboard;
        private System.Windows.Forms.Button BtnCattle;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
    }
}


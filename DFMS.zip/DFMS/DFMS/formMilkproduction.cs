﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DFMS
{
    public partial class formMilkproduction : Form
    {
        public formMilkproduction()
        {
            InitializeComponent();
        }

        private void formMilkproduction_FormClosed(object sender, FormClosedEventArgs e)
        {

        }

        private void milkproductionTblBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.milkproductionTblBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dairymanagementDataSet);

        }

        private void formMilkproduction_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dairymanagementDataSet.CowTbl' table. You can move, or remove it, as needed.
            this.cowTblTableAdapter.Fill(this.dairymanagementDataSet.CowTbl);
            // TODO: This line of code loads data into the 'dairymanagementDataSet.MilkproductionTbl' table. You can move, or remove it, as needed.
            this.milkproductionTblTableAdapter.Fill(this.dairymanagementDataSet.MilkproductionTbl);

        }


        private void BtnAdd_Click(object sender, EventArgs e)
        {
            this.milkproductionTblBindingSource.AddNew();
        }
        
        int amMilk, noonMilk, pmMilk;
        int totalMilk = 0;

        public void milkTotalfunc()
        {
            
            amMilk = int.Parse(amMilkTextBox.Text);
            noonMilk = int.Parse(noonMilkTextBox.Text);
            pmMilk = int.Parse(pmMilkTextBox.Text);

            totalMilk = amMilk + noonMilk + pmMilk;

            totalMilkTextBox.Text = totalMilk.ToString();

        }
       
        
        private void BtnSave_Click(object sender, EventArgs e)
        {
            milkTotalfunc();
            
            System.Media.SystemSounds.Beep.Play();
            this.milkproductionTblBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dairymanagementDataSet);
            MessageBox.Show("Record Saved successfuly!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

            //amMilk = 0; noonMilk = 0;  pmMilk = 0;totalMilk = 0;
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            System.Media.SystemSounds.Beep.Play();
            if (MessageBox.Show("Are you sure you want to delete the record?", "Confirm deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.milkproductionTblBindingSource.RemoveCurrent();
                this.tableAdapterManager.UpdateAll(this.dairymanagementDataSet);
                MessageBox.Show("Record Deleted successfuly!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Btnback_Click(object sender, EventArgs e)
        {
            System.Media.SystemSounds.Beep.Play();
            if (MessageBox.Show("Are you sure you want to go back?", "Confirm Back", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Form1 menuForm = new Form1();
                menuForm.Show();
                this.Close();
            }

        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            System.Media.SystemSounds.Beep.Play();
            if (MessageBox.Show("Are you sure you want to exit?", "Confirm exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}

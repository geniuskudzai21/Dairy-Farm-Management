﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DFMS
{
    public partial class formMilksales : Form
    {
        public formMilksales()
        {
            InitializeComponent();
        }

        private void formMilksales_FormClosed(object sender, FormClosedEventArgs e)
        {

        }

        private void milkSalesTblBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.milkSalesTblBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dairymanagementDataSet);

        }

        private void formMilksales_Load(object sender, EventArgs e)
        {
           
            this.employeeTblTableAdapter.Fill(this.dairymanagementDataSet.EmployeeTbl);
      
            this.milkSalesTblTableAdapter.Fill(this.dairymanagementDataSet.MilkSalesTbl);

        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            this.milkSalesTblBindingSource.AddNew();
        }
        int price, quantity;
        int total = 0;
        public void calcTotal()
        {
            price = int.Parse(priceTextBox.Text);
            quantity = int.Parse(quantityTextBox.Text);
            total = price * quantity;
            totalTextBox.Text = total.ToString();
        }

       
        private void BtnSave_Click(object sender, EventArgs e)
        {

            calcTotal();

            System.Media.SystemSounds.Beep.Play();
            this.milkSalesTblBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dairymanagementDataSet);
            MessageBox.Show("Milk Sales Record Saved successfuly!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            MessageBox.Show("Income Sales Record Saved successfuly!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            System.Media.SystemSounds.Beep.Play();
            if (MessageBox.Show("Are you sure you want to delete the record?", "Confirm deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.milkSalesTblBindingSource.RemoveCurrent();
                this.tableAdapterManager.UpdateAll(this.dairymanagementDataSet);
                MessageBox.Show("Record Deleted successfuly!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void Btnback_Click(object sender, EventArgs e)
        {
            System.Media.SystemSounds.Beep.Play();
            if (MessageBox.Show("Are you sure you want to go back?", "Confirm Back", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Form1 menuForm = new Form1();
                menuForm.Show();
                this.Close();
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            System.Media.SystemSounds.Beep.Play();
            if (MessageBox.Show("Are you sure you want to exit?", "Confirm exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DFMS
{
    public partial class formBreeding : Form
    {
        public formBreeding()
        {
            InitializeComponent();
        }

        private void breedTblBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.breedTblBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dairymanagementDataSet);

        }

        private void formBreeding_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dairymanagementDataSet.CowTbl' table. You can move, or remove it, as needed.
            this.cowTblTableAdapter.Fill(this.dairymanagementDataSet.CowTbl);
            // TODO: This line of code loads data into the 'dairymanagementDataSet.BreedTbl' table. You can move, or remove it, as needed.
            this.breedTblTableAdapter.Fill(this.dairymanagementDataSet.BreedTbl);

        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            this.breedTblBindingSource.AddNew();
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            System.Media.SystemSounds.Beep.Play();
            this.breedTblBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dairymanagementDataSet);
            MessageBox.Show("Record Saved successfuly!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            System.Media.SystemSounds.Beep.Play();
            if (MessageBox.Show("Are you sure you want to delete the record?", "Confirm deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.breedTblBindingSource.RemoveCurrent();
                this.tableAdapterManager.UpdateAll(this.dairymanagementDataSet);
                MessageBox.Show("Record Deleted successfuly!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            System.Media.SystemSounds.Beep.Play();
            if (MessageBox.Show("Are you sure you want to go back?", "Confirm Back", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Form1 menuForm = new Form1();
                menuForm.Show();
                this.Close();
            }
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            System.Media.SystemSounds.Beep.Play();
            if (MessageBox.Show("Are you sure you want to exit?", "Confirm exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}

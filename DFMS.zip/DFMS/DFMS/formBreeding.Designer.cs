﻿namespace DFMS
{
    partial class formBreeding
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label cow_idLabel;
            System.Windows.Forms.Label heatDateLabel;
            System.Windows.Forms.Label breedDateLabel;
            System.Windows.Forms.Label pregDateLabel;
            System.Windows.Forms.Label expDateCalveLabel;
            System.Windows.Forms.Label dateCalvedLabel;
            System.Windows.Forms.Label cowAgeLabel;
            System.Windows.Forms.Label remarksLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formBreeding));
            this.dairymanagementDataSet = new DFMS.dairymanagementDataSet();
            this.breedTblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.breedTblTableAdapter = new DFMS.dairymanagementDataSetTableAdapters.BreedTblTableAdapter();
            this.tableAdapterManager = new DFMS.dairymanagementDataSetTableAdapters.TableAdapterManager();
            this.breedTblDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cow_idComboBox = new System.Windows.Forms.ComboBox();
            this.cowTblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.heatDateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.breedDateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.pregDateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.expDateCalveDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.dateCalvedDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.cowAgeTextBox = new System.Windows.Forms.TextBox();
            this.remarksTextBox = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.BtnExit = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.BtnDelete = new Guna.UI2.WinForms.Guna2Button();
            this.BtnAdd = new Guna.UI2.WinForms.Guna2Button();
            this.BtnSave = new Guna.UI2.WinForms.Guna2Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cowTblTableAdapter = new DFMS.dairymanagementDataSetTableAdapters.CowTblTableAdapter();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            cow_idLabel = new System.Windows.Forms.Label();
            heatDateLabel = new System.Windows.Forms.Label();
            breedDateLabel = new System.Windows.Forms.Label();
            pregDateLabel = new System.Windows.Forms.Label();
            expDateCalveLabel = new System.Windows.Forms.Label();
            dateCalvedLabel = new System.Windows.Forms.Label();
            cowAgeLabel = new System.Windows.Forms.Label();
            remarksLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dairymanagementDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.breedTblBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.breedTblDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cowTblBindingSource)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // cow_idLabel
            // 
            cow_idLabel.AutoSize = true;
            cow_idLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            cow_idLabel.Location = new System.Drawing.Point(6, 18);
            cow_idLabel.Name = "cow_idLabel";
            cow_idLabel.Size = new System.Drawing.Size(58, 16);
            cow_idLabel.TabIndex = 2;
            cow_idLabel.Text = "Cow id:";
            // 
            // heatDateLabel
            // 
            heatDateLabel.AutoSize = true;
            heatDateLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            heatDateLabel.Location = new System.Drawing.Point(5, 50);
            heatDateLabel.Name = "heatDateLabel";
            heatDateLabel.Size = new System.Drawing.Size(82, 16);
            heatDateLabel.TabIndex = 4;
            heatDateLabel.Text = "Heat Date:";
            // 
            // breedDateLabel
            // 
            breedDateLabel.AutoSize = true;
            breedDateLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            breedDateLabel.Location = new System.Drawing.Point(5, 85);
            breedDateLabel.Name = "breedDateLabel";
            breedDateLabel.Size = new System.Drawing.Size(91, 16);
            breedDateLabel.TabIndex = 6;
            breedDateLabel.Text = "Breed Date:";
            // 
            // pregDateLabel
            // 
            pregDateLabel.AutoSize = true;
            pregDateLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            pregDateLabel.Location = new System.Drawing.Point(5, 116);
            pregDateLabel.Name = "pregDateLabel";
            pregDateLabel.Size = new System.Drawing.Size(82, 16);
            pregDateLabel.TabIndex = 8;
            pregDateLabel.Text = "Preg Date:";
            // 
            // expDateCalveLabel
            // 
            expDateCalveLabel.AutoSize = true;
            expDateCalveLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            expDateCalveLabel.Location = new System.Drawing.Point(349, 23);
            expDateCalveLabel.Name = "expDateCalveLabel";
            expDateCalveLabel.Size = new System.Drawing.Size(119, 16);
            expDateCalveLabel.TabIndex = 10;
            expDateCalveLabel.Text = "Exp Date Calve:";
            // 
            // dateCalvedLabel
            // 
            dateCalvedLabel.AutoSize = true;
            dateCalvedLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dateCalvedLabel.Location = new System.Drawing.Point(349, 53);
            dateCalvedLabel.Name = "dateCalvedLabel";
            dateCalvedLabel.Size = new System.Drawing.Size(98, 16);
            dateCalvedLabel.TabIndex = 12;
            dateCalvedLabel.Text = "Date Calved:";
            // 
            // cowAgeLabel
            // 
            cowAgeLabel.AutoSize = true;
            cowAgeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            cowAgeLabel.Location = new System.Drawing.Point(350, 86);
            cowAgeLabel.Name = "cowAgeLabel";
            cowAgeLabel.Size = new System.Drawing.Size(73, 16);
            cowAgeLabel.TabIndex = 14;
            cowAgeLabel.Text = "Cow Age:";
            // 
            // remarksLabel
            // 
            remarksLabel.AutoSize = true;
            remarksLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            remarksLabel.Location = new System.Drawing.Point(349, 117);
            remarksLabel.Name = "remarksLabel";
            remarksLabel.Size = new System.Drawing.Size(74, 16);
            remarksLabel.TabIndex = 16;
            remarksLabel.Text = "Remarks:";
            // 
            // dairymanagementDataSet
            // 
            this.dairymanagementDataSet.DataSetName = "dairymanagementDataSet";
            this.dairymanagementDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // breedTblBindingSource
            // 
            this.breedTblBindingSource.DataMember = "BreedTbl";
            this.breedTblBindingSource.DataSource = this.dairymanagementDataSet;
            // 
            // breedTblTableAdapter
            // 
            this.breedTblTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.BreedTblTableAdapter = this.breedTblTableAdapter;
            this.tableAdapterManager.CowTblTableAdapter = null;
            this.tableAdapterManager.EmployeeTblTableAdapter = null;
            this.tableAdapterManager.ExpenditureTableAdapter = null;
            this.tableAdapterManager.HealthTblTableAdapter = null;
            this.tableAdapterManager.IncomeTblTableAdapter = null;
            this.tableAdapterManager.MilkproductionTblTableAdapter = null;
            this.tableAdapterManager.MilkSalesTblTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = DFMS.dairymanagementDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // breedTblDataGridView
            // 
            this.breedTblDataGridView.AutoGenerateColumns = false;
            this.breedTblDataGridView.BackgroundColor = System.Drawing.Color.White;
            this.breedTblDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.breedTblDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8});
            this.breedTblDataGridView.DataSource = this.breedTblBindingSource;
            this.breedTblDataGridView.Location = new System.Drawing.Point(6, 305);
            this.breedTblDataGridView.Name = "breedTblDataGridView";
            this.breedTblDataGridView.Size = new System.Drawing.Size(1010, 275);
            this.breedTblDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Cow_id";
            this.dataGridViewTextBoxColumn1.HeaderText = "Cow_id";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn2.DataPropertyName = "HeatDate";
            this.dataGridViewTextBoxColumn2.HeaderText = "HeatDate";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn3.DataPropertyName = "BreedDate";
            this.dataGridViewTextBoxColumn3.HeaderText = "BreedDate";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn4.DataPropertyName = "PregDate";
            this.dataGridViewTextBoxColumn4.HeaderText = "PregDate";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn5.DataPropertyName = "ExpDateCalve";
            this.dataGridViewTextBoxColumn5.HeaderText = "ExpDateCalve";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn6.DataPropertyName = "DateCalved";
            this.dataGridViewTextBoxColumn6.HeaderText = "DateCalved";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "CowAge";
            this.dataGridViewTextBoxColumn7.HeaderText = "CowAge";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Remarks";
            this.dataGridViewTextBoxColumn8.HeaderText = "Remarks";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // cow_idComboBox
            // 
            this.cow_idComboBox.BackColor = System.Drawing.Color.White;
            this.cow_idComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.breedTblBindingSource, "Cow_id", true));
            this.cow_idComboBox.DataSource = this.cowTblBindingSource;
            this.cow_idComboBox.DisplayMember = "CowID";
            this.cow_idComboBox.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.cow_idComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cow_idComboBox.FormattingEnabled = true;
            this.cow_idComboBox.Location = new System.Drawing.Point(96, 13);
            this.cow_idComboBox.Name = "cow_idComboBox";
            this.cow_idComboBox.Size = new System.Drawing.Size(221, 24);
            this.cow_idComboBox.TabIndex = 3;
            this.cow_idComboBox.ValueMember = "CowID";
            // 
            // cowTblBindingSource
            // 
            this.cowTblBindingSource.DataMember = "CowTbl";
            this.cowTblBindingSource.DataSource = this.dairymanagementDataSet;
            // 
            // heatDateDateTimePicker
            // 
            this.heatDateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.breedTblBindingSource, "HeatDate", true));
            this.heatDateDateTimePicker.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.heatDateDateTimePicker.Location = new System.Drawing.Point(96, 45);
            this.heatDateDateTimePicker.Name = "heatDateDateTimePicker";
            this.heatDateDateTimePicker.Size = new System.Drawing.Size(221, 22);
            this.heatDateDateTimePicker.TabIndex = 5;
            // 
            // breedDateDateTimePicker
            // 
            this.breedDateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.breedTblBindingSource, "BreedDate", true));
            this.breedDateDateTimePicker.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.breedDateDateTimePicker.Location = new System.Drawing.Point(96, 80);
            this.breedDateDateTimePicker.Name = "breedDateDateTimePicker";
            this.breedDateDateTimePicker.Size = new System.Drawing.Size(221, 22);
            this.breedDateDateTimePicker.TabIndex = 7;
            // 
            // pregDateDateTimePicker
            // 
            this.pregDateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.breedTblBindingSource, "PregDate", true));
            this.pregDateDateTimePicker.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pregDateDateTimePicker.Location = new System.Drawing.Point(96, 113);
            this.pregDateDateTimePicker.Name = "pregDateDateTimePicker";
            this.pregDateDateTimePicker.Size = new System.Drawing.Size(221, 22);
            this.pregDateDateTimePicker.TabIndex = 9;
            // 
            // expDateCalveDateTimePicker
            // 
            this.expDateCalveDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.breedTblBindingSource, "ExpDateCalve", true));
            this.expDateCalveDateTimePicker.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.expDateCalveDateTimePicker.Location = new System.Drawing.Point(474, 17);
            this.expDateCalveDateTimePicker.Name = "expDateCalveDateTimePicker";
            this.expDateCalveDateTimePicker.Size = new System.Drawing.Size(237, 22);
            this.expDateCalveDateTimePicker.TabIndex = 11;
            // 
            // dateCalvedDateTimePicker
            // 
            this.dateCalvedDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.breedTblBindingSource, "DateCalved", true));
            this.dateCalvedDateTimePicker.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateCalvedDateTimePicker.Location = new System.Drawing.Point(474, 47);
            this.dateCalvedDateTimePicker.Name = "dateCalvedDateTimePicker";
            this.dateCalvedDateTimePicker.Size = new System.Drawing.Size(237, 22);
            this.dateCalvedDateTimePicker.TabIndex = 13;
            // 
            // cowAgeTextBox
            // 
            this.cowAgeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.breedTblBindingSource, "CowAge", true));
            this.cowAgeTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cowAgeTextBox.Location = new System.Drawing.Point(475, 81);
            this.cowAgeTextBox.Name = "cowAgeTextBox";
            this.cowAgeTextBox.Size = new System.Drawing.Size(237, 22);
            this.cowAgeTextBox.TabIndex = 15;
            // 
            // remarksTextBox
            // 
            this.remarksTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.breedTblBindingSource, "Remarks", true));
            this.remarksTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.remarksTextBox.Location = new System.Drawing.Point(474, 113);
            this.remarksTextBox.Multiline = true;
            this.remarksTextBox.Name = "remarksTextBox";
            this.remarksTextBox.Size = new System.Drawing.Size(237, 56);
            this.remarksTextBox.TabIndex = 17;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Controls.Add(this.pictureBox3);
            this.groupBox1.Controls.Add(this.pictureBox2);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.breedTblDataGridView);
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1022, 586);
            this.groupBox1.TabIndex = 18;
            this.groupBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(6, 73);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(1010, 10);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 25;
            this.pictureBox2.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.BtnExit);
            this.groupBox3.Controls.Add(this.guna2Button1);
            this.groupBox3.Controls.Add(this.BtnDelete);
            this.groupBox3.Controls.Add(this.BtnAdd);
            this.groupBox3.Controls.Add(this.BtnSave);
            this.groupBox3.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.groupBox3.Location = new System.Drawing.Point(735, 88);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(281, 180);
            this.groupBox3.TabIndex = 24;
            this.groupBox3.TabStop = false;
            // 
            // BtnExit
            // 
            this.BtnExit.BorderRadius = 17;
            this.BtnExit.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.BtnExit.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.BtnExit.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.BtnExit.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.BtnExit.FillColor = System.Drawing.Color.Black;
            this.BtnExit.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnExit.ForeColor = System.Drawing.Color.White;
            this.BtnExit.Location = new System.Drawing.Point(160, 123);
            this.BtnExit.Name = "BtnExit";
            this.BtnExit.Size = new System.Drawing.Size(106, 36);
            this.BtnExit.TabIndex = 24;
            this.BtnExit.Text = "Exit";
            this.BtnExit.Click += new System.EventHandler(this.BtnExit_Click);
            // 
            // guna2Button1
            // 
            this.guna2Button1.BorderRadius = 17;
            this.guna2Button1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button1.FillColor = System.Drawing.Color.Black;
            this.guna2Button1.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button1.ForeColor = System.Drawing.Color.White;
            this.guna2Button1.Location = new System.Drawing.Point(160, 75);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.Size = new System.Drawing.Size(106, 36);
            this.guna2Button1.TabIndex = 23;
            this.guna2Button1.Text = "Back";
            this.guna2Button1.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // BtnDelete
            // 
            this.BtnDelete.BorderRadius = 17;
            this.BtnDelete.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.BtnDelete.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.BtnDelete.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.BtnDelete.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.BtnDelete.FillColor = System.Drawing.Color.Black;
            this.BtnDelete.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnDelete.ForeColor = System.Drawing.Color.White;
            this.BtnDelete.Location = new System.Drawing.Point(27, 123);
            this.BtnDelete.Name = "BtnDelete";
            this.BtnDelete.Size = new System.Drawing.Size(106, 36);
            this.BtnDelete.TabIndex = 18;
            this.BtnDelete.Text = "Delete";
            this.BtnDelete.Click += new System.EventHandler(this.BtnDelete_Click);
            // 
            // BtnAdd
            // 
            this.BtnAdd.BorderRadius = 17;
            this.BtnAdd.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.BtnAdd.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.BtnAdd.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.BtnAdd.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.BtnAdd.FillColor = System.Drawing.Color.Black;
            this.BtnAdd.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAdd.ForeColor = System.Drawing.Color.White;
            this.BtnAdd.Location = new System.Drawing.Point(27, 23);
            this.BtnAdd.Name = "BtnAdd";
            this.BtnAdd.Size = new System.Drawing.Size(239, 33);
            this.BtnAdd.TabIndex = 17;
            this.BtnAdd.Text = "Add";
            this.BtnAdd.Click += new System.EventHandler(this.BtnAdd_Click);
            // 
            // BtnSave
            // 
            this.BtnSave.BorderRadius = 17;
            this.BtnSave.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.BtnSave.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.BtnSave.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.BtnSave.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.BtnSave.FillColor = System.Drawing.Color.Black;
            this.BtnSave.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSave.ForeColor = System.Drawing.Color.White;
            this.BtnSave.Location = new System.Drawing.Point(27, 75);
            this.BtnSave.Name = "BtnSave";
            this.BtnSave.Size = new System.Drawing.Size(106, 36);
            this.BtnSave.TabIndex = 16;
            this.BtnSave.Text = "Save";
            this.BtnSave.Click += new System.EventHandler(this.BtnSave_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(6, 274);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1010, 25);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 23;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Algerian", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(321, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(359, 54);
            this.label1.TabIndex = 22;
            this.label1.Text = "BREEDING FILE";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(cow_idLabel);
            this.groupBox2.Controls.Add(this.pregDateDateTimePicker);
            this.groupBox2.Controls.Add(this.remarksTextBox);
            this.groupBox2.Controls.Add(pregDateLabel);
            this.groupBox2.Controls.Add(remarksLabel);
            this.groupBox2.Controls.Add(this.breedDateDateTimePicker);
            this.groupBox2.Controls.Add(this.cowAgeTextBox);
            this.groupBox2.Controls.Add(this.cow_idComboBox);
            this.groupBox2.Controls.Add(cowAgeLabel);
            this.groupBox2.Controls.Add(breedDateLabel);
            this.groupBox2.Controls.Add(this.dateCalvedDateTimePicker);
            this.groupBox2.Controls.Add(this.heatDateDateTimePicker);
            this.groupBox2.Controls.Add(dateCalvedLabel);
            this.groupBox2.Controls.Add(heatDateLabel);
            this.groupBox2.Controls.Add(this.expDateCalveDateTimePicker);
            this.groupBox2.Controls.Add(expDateCalveLabel);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(6, 88);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(723, 180);
            this.groupBox2.TabIndex = 21;
            this.groupBox2.TabStop = false;
            // 
            // cowTblTableAdapter
            // 
            this.cowTblTableAdapter.ClearBeforeFill = true;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(910, 3);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.pictureBox3.Size = new System.Drawing.Size(102, 67);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 28;
            this.pictureBox3.TabStop = false;
            // 
            // formBreeding
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1027, 595);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "formBreeding";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "formBreeding";
            this.Load += new System.EventHandler(this.formBreeding_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dairymanagementDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.breedTblBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.breedTblDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cowTblBindingSource)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private dairymanagementDataSet dairymanagementDataSet;
        private System.Windows.Forms.BindingSource breedTblBindingSource;
        private dairymanagementDataSetTableAdapters.BreedTblTableAdapter breedTblTableAdapter;
        private dairymanagementDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView breedTblDataGridView;
        private System.Windows.Forms.ComboBox cow_idComboBox;
        private System.Windows.Forms.DateTimePicker heatDateDateTimePicker;
        private System.Windows.Forms.DateTimePicker breedDateDateTimePicker;
        private System.Windows.Forms.DateTimePicker pregDateDateTimePicker;
        private System.Windows.Forms.DateTimePicker expDateCalveDateTimePicker;
        private System.Windows.Forms.DateTimePicker dateCalvedDateTimePicker;
        private System.Windows.Forms.TextBox cowAgeTextBox;
        private System.Windows.Forms.TextBox remarksTextBox;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox3;
        private Guna.UI2.WinForms.Guna2Button BtnExit;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2Button BtnDelete;
        private Guna.UI2.WinForms.Guna2Button BtnAdd;
        private Guna.UI2.WinForms.Guna2Button BtnSave;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.BindingSource cowTblBindingSource;
        private dairymanagementDataSetTableAdapters.CowTblTableAdapter cowTblTableAdapter;
        private System.Windows.Forms.PictureBox pictureBox3;
    }
}